import random
highest=100
answer = random.randint(1,highest)
print(answer)