import sys
sys.maxsize
sys.path