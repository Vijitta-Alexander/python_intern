l = ['bhuvan','harish','arun','parveen']
def module(l):
    return l
print(module(l))