import MODULE
MODULE.list1[1]="balaji"
print(MODULE)